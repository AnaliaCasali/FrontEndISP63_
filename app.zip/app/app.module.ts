import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { EncabezadoComponent } from './componentes/encabezado/encabezado.component';
import { PiePaginaComponent } from './componentes/pie-pagina/pie-pagina.component';

import { HttpClientModule } from '@angular/common/http';
import { CarreraComponent } from './componentes/carrera/carrera.component';
import { NewCarreraComponent } from './componentes/new-carrera/new-carrera.component';
import { InscripcionComponent } from './componentes/inscripcion/inscripcion.component';
import { MesaExamenComponent } from './componentes/mesa-examen/mesa-examen.component';
import { AlumnoComponent } from './componentes/alumno/alumno.component';
import { ReactiveFormsModule } from '@angular/forms';
import {FormsModule} from '@angular/forms';
import { AsignaturaComponent } from './componentes/asignatura/asignatura.component';
import { NewInscripcionComponent } from './componentes/new-inscripcion/new-inscripcion.component';
import {MatListModule} from '@angular/material/list';


@NgModule({
  declarations: [
    AppComponent,
    EncabezadoComponent,
    PiePaginaComponent,
  
    CarreraComponent,
    NewCarreraComponent,
    InscripcionComponent,
    MesaExamenComponent,
    AlumnoComponent,
    AsignaturaComponent,
    NewInscripcionComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule,
    FormsModule,
    MatListModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
