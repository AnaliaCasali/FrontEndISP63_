import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AlumnoService } from 'src/app/Services/alumno.service';
import { AsignaturaService } from 'src/app/Services/asignatura.service';
import { InscripcionService } from 'src/app/Services/inscripcion.service';
import { MesaExamenService } from 'src/app/Services/mesa-examen.service';
import { TurnoService } from 'src/app/Services/turno.service';
import { Alumno } from 'src/app/models/alumno';
import { Asignatura } from 'src/app/models/asignatura';
import { Inscripcion } from 'src/app/models/inscripcion';
import { MesaExamen } from 'src/app/models/mesa-examen';
import { Turno } from 'src/app/models/turno';

@Component({
  selector: 'app-inscripciones',
  templateUrl: './inscripciones.component.html',
  styleUrls: ['./inscripciones.component.css']
})
export class InscripcionesComponent {

  title = 'lista de Inscripciones'
  id:number=-1;
  fech:Date= new Date;
  alumno!:Alumno;
  listaMesaExamen!: MesaExamen;
  turnoVigente!: Turno; 
  turnos:Turno[]=[];
  asignaturas:Asignatura[]=[];

  //componentes de selecion de lista
  listaAsignatura: Asignatura[]=[];
  opcionesSeleccionadas=[];
  opcionSeleccionada:any;
  


 


 listaMesa:MesaExamen[]=[];
 //ListaAsig:Asignatura[]=[];
 listaAlumno:Alumno[]=[];

  constructor(private datosInscripciones: InscripcionService, 
    private datosAlumno: AlumnoService, 
    private mesa: MesaExamenService,
    private turno: TurnoService,
     private asignatura: AsignaturaService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
     ) { 



     }



  ngOnInit(): void {
   // this.cargarInscripcion();
     this.cargarTurno();
    //this.cargarAsig();
    this.cargarAlumno();
    this.cargarMesa();

  }

  onCreate(): void {
  
    //creo un objeto carrera y asigno los datos del
     //formulario a traves del constructor
   const newInscripcion = new Inscripcion(this.id,this.fech,this.alumno);
    // llamo al metodo guardar del service pasando la carrera y la imagen
    this.datosInscripciones.save(newInscripcion).subscribe( ); 
    console.log(this.id);
    console.log(this.alumno);
    console.log(this.listaMesaExamen);
  
    

  }

 /* cargarInscripcion(): void {
    this.datosInscripciones.lista().subscribe((data) => {
      this.inscripciones = data;
      console.log(data);
    });
  }*/
    cargarMesa(): void {
    this.mesa.lista().subscribe((data) => {
      this.listaMesa= data;
      console.log("mesas ", data);
    });
  }
  cargarTurno(): void {
    this.turno.detailVigente().subscribe((data) =>{
      this.turnoVigente = data;
      console.log(data);
    });
  }
  
   cargarAlumno(): void {
    this.datosAlumno.lista().subscribe((data)=>{
      this.listaAlumno= data;
      console.log(data);

    });

    // CON LOS DOS PARAMETROS ALUMNO..
    //Y CON LOS DATOS DE TURNO CREO UN LLAMADO PARA BUSCAR LAS MATERIAS... 
   //CREO UN METODO CON EL ID DE ALUMNO Y ID DE LA CARRERA DEL ALUMNO PARA LUEGO LISTAR EL CHECBOK
    

  }
  /*cargarAsig(): void {
    this.asignatura.listAsignatura(1).subscribe((data) => {
      this.ListaAsig = data;
      console.log("asignaturas " + data);
    }) 
}*/
onNgModelChange($event:any){
  console.log($event);
  this.opcionSeleccionada=$event;
}



  /*delete(id?: number) {
    if (id != undefined) {
      this.datosInscripciones.delete(id).subscribe((data) => {
        this.cargarInscripcion();
      },
        (err) => {
          alert('no se pudo borrar la inscripcion');
        }
      );
    }
  }
  
 showOk (msgOk: string){ Swal.fire({
    title: 'Genial!',
    text: msgOk,
    icon: 'success',
    confirmButtonText: 'Aceptar'
  }); }


  showOk (msgOk: string){ ({
    title: 'Genial!',
    text: msgOk,
    icon: 'success',
    confirmButtonText: 'Aceptar'
  }); }*/

}
