import { Component } from '@angular/core';

@Component({
  selector: 'piepagina',
  templateUrl: './pie-pagina.component.html',
  styleUrls: ['./pie-pagina.component.css']
})
export class PiePaginaComponent {

  texto =" Esta es la web institutcional de ISP 63 {{INTERPOLACION}}"

}
