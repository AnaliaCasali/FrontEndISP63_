import { Component } from '@angular/core';
import { ActivatedRoute, RouteReuseStrategy } from '@angular/router';
import { Carrera } from 'src/app/models/carrera';
import { CarreraService } from 'src/app/Services/carrera.service';


@Component({
  selector: 'app-carrera',
  templateUrl: './carrera.component.html',
  styleUrls: ['./carrera.component.css']
})
export class CarreraComponent {
  title = 'lista de Carreras'
  carreras: Carrera[] = [];
  constructor(private datosCarreras: CarreraService
    // private router: RouteReuseStrategy;
    //private activateRouter:ActivatedRoute;
  ) { }

  ngOnInit(): void {
    this.cargarCarreras();
    /*if(this.activatedRouter.snapshot.params['id'] === undefined)
      this.isNew=true;
      else{
        this.id=this.activatedRouter.snapshot.params['id'];
        this.carreraService.detail(this.id).subscribe(

          next:(data)
        )
      }
    */
  }

  cargarCarreras(): void {
    this.datosCarreras.lista().subscribe((data) => {
      this.carreras = data;
      console.log(data);
    });
  }

  delete(id?: number) {
    if (id != undefined) {
      this.datosCarreras.delete(id).subscribe(
        (data) => {
          this.cargarCarreras();
        },
        (err) => {
          alert('no se pudo borrar la carrera');
        }
      );
    }

  }


 /*  showError(msgNoOk: String) {
    Swal.fire({
      title: 'Error!',
      text: msgNoOk,
      icon: 'error',
      confirmBurronText: 'Aceptar'

    });
  }

  showOk(msgOk:String){Swal.fire({
    title: 'Genial!',
    text: msgOk,
    icon: 'succes',
    confirmBurronText: 'Aceptar'
  })

  }
  */ 
  }




