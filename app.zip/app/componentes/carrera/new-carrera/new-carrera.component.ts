import { Component } from '@angular/core';

@Component({
  selector: 'app-new-carrera',
  templateUrl: './new-carrera.component.html',
  styleUrls: ['./new-carrera.component.css']
})
export class NewCarreraComponent {
  
}
