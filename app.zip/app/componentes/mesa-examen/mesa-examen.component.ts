import { Component } from '@angular/core';
import { AsignaturaService } from 'src/app/Services/asignatura.service';
import { MesaExamenService } from 'src/app/Services/mesa-examen.service';
import { TurnoService } from 'src/app/Services/turno.service';
import { Asignatura } from 'src/app/models/asignatura';
import { MesaExamen } from 'src/app/models/mesa-examen';
import { Turno } from 'src/app/models/turno';


@Component({
  selector: 'app-mesa-examen',
  templateUrl: './mesa-examen.component.html',
  styleUrls: ['./mesa-examen.component.css']
})
export class MesaExamenComponent {
  title = 'lista de mesas'
  id: number = -1;
  fecha: Date = new Date;
  horario: String = "";
  tribunal: String = "";
  asignatura!: Asignatura;
  turno!: Turno;
  

  //listas cargadas con datos
  //asginatura
  ltAsig: Asignatura[] = [];
  lturno:Turno[] = [];

  //listas para cargar asgi

  listaAsig: Asignatura[] = [];
  opcionesSeleccionadas = [];
  opcionSeleccionada: any;

  constructor(private datosMesa: MesaExamenService, private datosAsig: AsignaturaService, private datosTurno:TurnoService) { }



  ngOnInit(): void {
    this.cargarAsig();
    //    this.cargarInscripcion();
    this.cargarTurno();
   
  }

  onNgModelChange($event: any) {
    console.log($event);
    this.opcionSeleccionada = $event;
  }

  cargarAsig(): void {
    this.datosAsig.lista().subscribe((data) => {
      this.ltAsig = data;
    
    })
  }

  cargarTurno():void{
    this.datosTurno.detailVigente().subscribe((data)=>{
      this.turno=data;
      console.log(this.lturno);
    });
  }




  /*  delete(id?: number) {
     if (id != undefined) {
       this.datosMesa.delete(id).subscribe((data) => {
         this.cargarInscripcion();
       },
         (err) => {
           alert('no se pudo borrar la mesa');
         }
       );
     }
   }*/
  onCreate(): void {

    console.log("id " + this.id);
    console.log("fecha " + this.fecha);
    console.log("horario "+this.horario);
    console.log("tribunal "+this.tribunal);
    console.log("turno " + this.turno);
    console.log("materia " + this.asignatura);
    


    //creo un objeto carrera y asigno los datos del
    //formulario a traves del constructor
    const newMesa = new MesaExamen(this.id, this.fecha,this.horario,this.tribunal,this.asignatura,this.turno);
    // llamo al metodo guardar del service pasando la carrera y la imagen
   this.datosMesa.save(newMesa).subscribe();
  }

}
