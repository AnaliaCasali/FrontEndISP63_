import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AlumnoService } from 'src/app/Services/alumno.service';
import { AsignaturaService } from 'src/app/Services/asignatura.service';
import { InscripcionService } from 'src/app/Services/inscripcion.service';
import { MesaExamenService } from 'src/app/Services/mesa-examen.service';
import { TurnoService } from 'src/app/Services/turno.service';
import { Alumno } from 'src/app/models/alumno';
import { Asignatura } from 'src/app/models/asignatura';
import { Inscripcion } from 'src/app/models/inscripcion';
import { MesaExamen } from 'src/app/models/mesa-examen';
import { Turno } from 'src/app/models/turno';

@Component({
  selector: 'app-new-inscripcion',
  templateUrl: './new-inscripcion.component.html',
  styleUrls: ['./new-inscripcion.component.css']
})
export class NewInscripcionComponent {  
  title = 'lista de Inscripciones'
  id:number=-1;
  fecha:Date= new Date;
  alumno!:Alumno;
  turnoVigente!: Turno; 
  turnos:Turno[]=[];
  asignaturas:Asignatura[]=[];
  


 


 listaMesa:MesaExamen[]=[];
 ListaAsig:Asignatura[]=[];
 listaAlumno:Alumno[]=[];

  constructor(private datosInscripciones: InscripcionService, 
    private datosAlumno: AlumnoService, 
    private mesa: MesaExamenService,
    private turno: TurnoService,
     private asignatura: AsignaturaService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
     ) { 



     }



  ngOnInit(): void {
   // this.cargarInscripcion();
     this.cargarTurno();
    this.cargarAsig();
    this.cargarAlumno();
    this.cargarMesa();

  }

  onCreate(): void {
  
    //creo un objeto carrera y asigno los datos del
     //formulario a traves del constructor
   const newInscripcion = new Inscripcion(this.id,this.fecha,this.alumno);
    // llamo al metodo guardar del service pasando la carrera y la imagen
    this.datosInscripciones.save(newInscripcion).subscribe(
     
    ); 
    console.log(this.id);
    console.log(this.alumno);
    console.log(this.asignaturas);

  }

 /* cargarInscripcion(): void {
    this.datosInscripciones.lista().subscribe((data) => {
      this.inscripciones = data;
      console.log(data);
    });
  }*/
    cargarMesa(): void {
    this.mesa.lista().subscribe((data) => {
      this.listaMesa= data;
      console.log(data);
    });
  }
  cargarTurno(): void {
    this.turno.detailVigente().subscribe((data) =>{
      this.turnoVigente = data;
      console.log(data);
    });
  }
  
   cargarAlumno(): void {
    this.datosAlumno.lista().subscribe((data)=>{
      this.listaAlumno= data;
      console.log(data);

    });

    // CON LOS DOS PARAMETROS ALUMNO..
    //Y CON LOS DATOS DE TURNO CREO UN LLAMADO PARA BUSCAR LAS MATERIAS... 
   //CREO UN METODO CON EL ID DE ALUMNO Y ID DE LA CARRERA DEL ALUMNO PARA LUEGO LISTAR EL CHECBOK
    

  }
  cargarAsig(): void {
    this.asignatura.listAsignatura(1).subscribe((data) => {
      this.ListaAsig = data;
      console.log("asignaturas " + data);
    }) 
}


  /*delete(id?: number) {
    if (id != undefined) {
      this.datosInscripciones.delete(id).subscribe((data) => {
        this.cargarInscripcion();
      },
        (err) => {
          alert('no se pudo borrar la inscripcion');
        }
      );
    }
  }
  
 showOk (msgOk: string){ Swal.fire({
    title: 'Genial!',
    text: msgOk,
    icon: 'success',
    confirmButtonText: 'Aceptar'
  }); }


  showOk (msgOk: string){ ({
    title: 'Genial!',
    text: msgOk,
    icon: 'success',
    confirmButtonText: 'Aceptar'
  }); }*/
}
