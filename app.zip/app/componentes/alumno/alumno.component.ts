import { Component } from '@angular/core';
import { Observable } from 'rxjs';
import { AlumnoService } from 'src/app/Services/alumno.service';
import { Alumno } from 'src/app/models/alumno';
import { Carrera } from 'src/app/models/carrera';
import { Inscripcion } from 'src/app/models/inscripcion';

@Component({
  selector: 'app-alumno',
  templateUrl: './alumno.component.html',
  styleUrls: ['./alumno.component.css']
})
export class AlumnoComponent {
  title = 'lista de Inscripciones'
  id?:number;
  sede?:String;
  carrera?:Carrera;
  estado?:String;
  ingreso?:String;
  telefono?:number;
  nombre?:String;
  apellido?:String;
  email?:String;
  dni?:number;
  password?:number;
  inscripcion?:Inscripcion;


  alumnos: Alumno[] = [];
  constructor( private datosAlumno: AlumnoService) { }


  ngOnInit(): void {
    this.cargarAlumno();
  }

  cargarAlumno(): void {
    this.datosAlumno.lista().subscribe((data) => {
      this.alumnos = data;
      console.log(data);
    });
  }

 
   
  

  delete(id?: number) {
    if (id != undefined) {
      this.datosAlumno.delete(id).subscribe((data) => {
        this.cargarAlumno();
      },
        (err) => {
          alert('no se pudo borrar la inscripcion');
        }
      );
    }
  }

}
