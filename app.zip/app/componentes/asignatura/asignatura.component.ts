import { Component } from '@angular/core';
import { AsignaturaService } from 'src/app/Services/asignatura.service';
import { Asignatura } from 'src/app/models/asignatura';

@Component({
  selector: 'app-asignatura',
  templateUrl: './asignatura.component.html',
  styleUrls: ['./asignatura.component.css']
})
export class AsignaturaComponent {
  title = 'lista de asigntura'
  asignaturas: Asignatura[] = [];
  constructor(private datosAsignatura:AsignaturaService) { }

  

  ngOnInit(): void {
    this.cargarInscripcion();
  }

  cargarInscripcion(): void {
    this.datosAsignatura.lista().subscribe((data) => {
      this.asignaturas = data;
      console.log(data);
    });
  }

  delete(id?: number) {
    if (id != undefined) {
      this.datosAsignatura.delete(id).subscribe((data) => {
        this.cargarInscripcion();
      },
        (err) => {
          alert('no se pudo borrar la mesa');
        }
      );
    }
  }
}
