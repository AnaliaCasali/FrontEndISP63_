export class Carrera {

    id?:number;
    nombre?:String;
    sede?:String;
    horario?:String;
    campoOcupacional?:String;
    numeroPlan?:number;

    constructor(nombre: String, sede:String, horario:String,campoOcupacional:String,NumeroPlan:number){
            this.nombre=nombre;
            this.sede=sede;
            this.horario=horario;
            this.campoOcupacional=campoOcupacional;
            this.numeroPlan=NumeroPlan;
    }
}
