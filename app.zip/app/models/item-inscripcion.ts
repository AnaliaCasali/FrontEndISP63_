import { Inscripcion } from "./inscripcion";
import { MesaExamen } from "./mesa-examen";

export class ItemInscripcion {
    id?:number;
    mesaExamen?:MesaExamen;
    inscripcion?:Inscripcion;
    alta?:Boolean;
    items:Set<ItemInscripcion> []=[];

    constructor(id:number,mesa:MesaExamen,inscripcion:Inscripcion, alta:boolean){
        this.id=id;
        this.mesaExamen=mesa;
        this.inscripcion=inscripcion;
        this.alta=alta;   
    }
}
