
import { Alumno } from "./alumno";
import { MesaExamen } from "./mesa-examen";



export class Inscripcion {
    id?:number;
    fecha?: Date;
    alumno?:Alumno;
   
   
   
   

    constructor(id:number, fecha:Date, alumno: Alumno ) {
        this.id=id;
        this.fecha=fecha;
        this.alumno=alumno;
    
        

    }
}
