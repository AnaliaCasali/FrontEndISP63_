import { Asignatura } from "./asignatura";
import { Turno } from "./turno";

export class MesaExamen {
 

    id?: number;
    fecha:Date;
    horario?: String;
    tribunal?: String;
    asignatura?:Asignatura;
    turno?: Turno;
    

    

   
   

    constructor(id: number, fecha:Date, horario: String, tribunal: String, asignatura:Asignatura, turno: Turno) {
        this.id = id;
        this.fecha = fecha;
        this.horario = horario;
        this.tribunal = tribunal;
        this.asignatura=asignatura;
        this.turno=turno;
       

    }
}
