import { Carrera } from "./carrera";
import { Inscripcion } from "./inscripcion";

export class Alumno {

    /* long id;
    String sede;
    String carrera;
    String estado;
    String ingreso;

      long telefono;
     String nombre;
     String apellido;
     String email;
     long dni;
     long password;
    
     */

    id?:number;
    sede?:String;
    carrera?:Carrera;
    estado?:String;
    ingreso?:String;
    telefono?:number;
    nombre?:String;
    apellido?:String;
    email?:String;
    dni?:number;
    password?:number;
    inscripcion?:Inscripcion;

    constructor( id:number,sede:String,carrera:Carrera,estado:String,ingreso:String,telefono:number,nombre:String, apellido:String,email:String,dni:number,password:number,inscripcion:Inscripcion){
        this.id=id;
        this.sede=sede;
        this.carrera=carrera;
        this.estado=estado;
        this.ingreso=ingreso;
        this.telefono=telefono;
        this.telefono=telefono;
        this.nombre=nombre;
        this.apellido=apellido;
        this.email=email;
        this.dni=dni;
        this.password=password;
        this.inscripcion=inscripcion;
        
    }
    


    
}

