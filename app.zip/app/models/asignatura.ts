import { Carrera } from "./carrera";

export class Asignatura {

    id?: number;
    asignatura?: String;
    tipo?: String;
    carrera?: Carrera;
    anio?: number;
    cargaHorario?: number;
    duracion?: number;
    correlativaRendir?: String;
    correlativaCursar?: String;
    constructor(id: number, asignatura: String, tipo: String, carrera: Carrera, anio: number, cargaHorario: number, duracion: number, correlativaRendir: String, correlativaCursar: String) {
        this.id = id;
        this.asignatura = asignatura;
        this.tipo = tipo;
        this.carrera = carrera;
        this.anio = anio;
        this.duracion = duracion;
        this.cargaHorario = cargaHorario;
        this.correlativaCursar = correlativaCursar;
        this.correlativaRendir = correlativaRendir;


    }


}
