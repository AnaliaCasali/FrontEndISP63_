export class Turno {
   
     id?:number;
     turno?:String;
    vigente?: boolean;
     constructor(id:number, turno:String, vigente: boolean){
        this.id=id;
        this.turno=turno;
        this.vigente=vigente;

     }
   
}
