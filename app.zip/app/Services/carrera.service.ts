import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Carrera } from '../models/carrera';

@Injectable({
  providedIn: 'root'
})
export class CarreraService {

  
  URL = "http://localhost:8080/carrera";



  constructor(private http: HttpClient) {


  }

  public lista(): Observable<Carrera[]> {
    return this.http.get<Carrera[]>(this.URL);
  }
  public delete(id: number): Observable<any> {
    return this.http.delete<any>(this.URL + `/${id}`);
  }

public datail(id: number): Observable <Carrera> {
  return this.http.get<Carrera>(this.URL + `/detail/${id}`);
}

public save(id: number): Observable < any > {
  return this.http.post<any>(this.URL + `/create`, Carrera);
}
public update(id: number): Observable < Carrera > {
  return this.http.put<Carrera>(this.URL + `/update/${id}`, Carrera);
}

}
