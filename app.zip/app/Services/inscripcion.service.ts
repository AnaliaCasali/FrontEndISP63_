import { Injectable } from '@angular/core';
import { Inscripcion } from 'src/app/models/inscripcion';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Alumno } from '../models/alumno';
import { AlumnoService } from './alumno.service';

@Injectable({
  providedIn: 'root'
})
export class InscripcionService {


  URL="http://localhost:8080/inscripcion";
  

  constructor(private http:HttpClient) { 

    
  }

 /* ngonInit(){
    this.alumnoService.getAlumno().subscribe((usu:Alumno[])=>{
      this.alumnos=usu
    }, err=>console.error("error"));
  }*/

  public lista():Observable<Inscripcion[]>{
    return this.http.get<Inscripcion[]>(this.URL);
  }
 public delete(id:number):Observable<any>{
  return this.http.delete<any>(this.URL+`/${id}`);
 }

 public datail(id: number): Observable <Inscripcion> {
  return this.http.get<Inscripcion>(this.URL + `/detail/${id}`);
}

public save(inscripcion:Inscripcion): Observable < any > {
  return this.http.post<any>(this.URL, inscripcion);
}
 /*public save(inscripcion:Inscripcion ):Observable<any>{    
  const formData = new FormData();
  console.log( JSON.stringify(inscripcion));
  formData.append('inscripcion', JSON.stringify(inscripcion));
  console.log(formData);
 return this.http.post<any>(this.URL+`/create`, formData);  

}
  */

}

