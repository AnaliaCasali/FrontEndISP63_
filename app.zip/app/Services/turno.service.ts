import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Turno } from '../models/turno';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TurnoService {

  URL="http://localhost:8080/turno";

  
  

  constructor(private http:HttpClient) { 

    
  }
  getTurno():Observable<Turno[]>{
    return this.http.get<Turno[]>(this.URL);
  }

  public lista():Observable<Turno[]>{
    return this.http.get<Turno[]>(this.URL);
  }
 public delete(id:number):Observable<any>{
  return this.http.delete<Turno>(this.URL+`/${id}`);
 }

 public detail(id: number): Observable <Turno> {
  return this.http.get<Turno>(this.URL + `/detail/${id}`);
}

public detailVigente(): Observable <Turno> {
  return this.http.get<Turno>(this.URL + `/detailVigente`);
}

public save(id: number): Observable < any > {
  return this.http.post<any>(this.URL + `/create`, Turno);
}
/*public update(id: number):  < Turno > {
  return this.http.put<Turno>(this.URL + `/update/${id}`, Turno);
}*/

}
