import { Injectable } from '@angular/core';
import { MesaExamen } from '../models/mesa-examen';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class MesaExamenService {


  URL="http://localhost:8080/mesaExamen";
  

  constructor(private http:HttpClient) { 

    
  }

  public lista():Observable<MesaExamen[]>{
    return this.http.get<MesaExamen[]>(this.URL);
  }
 public delete(id:number):Observable<any>{
  return this.http.delete<any>(this.URL+`/${id}`);
 }

 public datail(id: number): Observable <MesaExamen> {
  return this.http.get<MesaExamen>(this.URL + `/detail/${id}`);
}

public save(mesaExamen:MesaExamen): Observable < any > {
  return this.http.post<any>(this.URL,mesaExamen);
}
public update(id: number): Observable < MesaExamen > {
  return this.http.put<MesaExamen>(this.URL + `/update/${id}`, MesaExamen);
}

}
