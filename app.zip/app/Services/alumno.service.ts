import { Injectable } from '@angular/core';
import { Alumno } from '../models/alumno';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AlumnoService {

  URL = "http://localhost:8080/alumno";


  constructor(private http:HttpClient) {


  }
 
  public lista(): Observable<Alumno[]>{
    return this.http.get<Alumno[]>(this.URL);
  }
  public delete(id: number): Observable<any>{
    return this.http.delete<any>(this.URL + `/${id}`);
  }

public datail(id: number): Observable <Alumno> {
  return this.http.get<Alumno>(this.URL + `/detail/${id}`);
}

public save(id: number): Observable < any > {
  return this.http.post<any>(this.URL + `/create`, Alumno);
}
public update(id: number): Observable < Alumno > {
  return this.http.put<Alumno>(this.URL + `/update/${id}`, Alumno);
}
}
