import { Injectable } from '@angular/core';
import { Asignatura } from '../models/asignatura';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AsignaturaService {
  URL = "http://localhost:8080/asignatura";


  constructor(private http:HttpClient) {


  }

  public lista(): Observable<Asignatura[]> {
    return this.http.get<Asignatura[]>(this.URL);
  }

  public listAsignatura(idCar:number): Observable<Asignatura[]> {
    return this.http.get<Asignatura[]>(this.URL +`/listAsignatura/${idCar}`);
  }
  public delete(id: number): Observable<any> {
    return this.http.delete<any>(this.URL + `/${id}`);
  }

public datail(id: number): Observable <Asignatura> {
  return this.http.get<Asignatura>(this.URL + `/detail/${id}`);
}

public save(id: number): Observable < any > {
  return this.http.post<any>(this.URL + `/create`, Asignatura);
}
public update(id: number): Observable < Asignatura > {
  return this.http.put<Asignatura>(this.URL + `/update/${id}`, Asignatura);
}
}
