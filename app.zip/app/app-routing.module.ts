import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
//import { NoticiasComponent } from './componentes/noticias/noticias.component';
//import { CarreraComponent } from './componentes/carrera/carrera.component';
import { InscripcionComponent } from './componentes/inscripcion/inscripcion.component';
import { MesaExamenComponent } from './componentes/mesa-examen/mesa-examen.component';
import { AlumnoComponent } from './componentes/alumno/alumno.component';

//import { AlumnoComponent } from './componentes/alumno/alumno.component';

const routes: Routes = [
//{path:'',component:NoticiasComponent},
//{path:'noticias', component:NoticiasComponent},
//{path:'carreras', component:CarreraComponent},
{path:'inscripciones', component:InscripcionComponent},
{path:'newExamen', component:MesaExamenComponent},
{path:'inscripcion', component:InscripcionComponent},
{path:'alumno', component:AlumnoComponent},
{path:'**', redirectTo:'component:NoticiasComponent', pathMatch:'full'}


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {

 }

